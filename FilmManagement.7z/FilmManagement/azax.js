/**
 * Created by akuma373 on 6/9/2016.
 */
function sendRequest(){
    var XHR = getXHR()
    if(XHR){
        XHR.open("GET","data/actor.json",true);
        XHR.onreadystatechange = function(){handleResponse(XHR);}
        XHR.send();
    }
}

function getXHR(){
    return new XMLHttpRequest();
}

function handleResponse(XHR) {
    if (XHR.readyState == 4) {

        var sideBar = document.getElementById('addData');

        persons = JSON.parse(XHR.responseText);

        for (var i = 0; i < persons.length; i++) {

            var table = document.getElementById("addData");
            var row = table.insertRow(i);
            var cell1 = row.insertCell(0);
            cell1.innerHTML = "<button type='button' class='btn btn-info btn-block' onclick='getDetail(this)' " +
                "id="+ i + ">" + persons[i].lastname + " " + persons[i].firstname + "</button>";
        }
    }
}


function getDetail(btn) {
    document.getElementById('firstname').value = persons[btn.id].firstname;

    document.getElementById('lastname').value = persons[btn.id].lastname;

    document.getElementById('gender').value = persons[btn.id].gender;



}



function change(){

    document.getElementById('form')
    for (var i = 0; i < persons.length; i++) {
        var table = document.getElementById("form");
        var row = table.insertRow(i);
        var cell1 = row.insertCell(0);
        cell1.innerHTML = "<button type='button' class='btn btn-info btn-block' onclick='getDetail(this)' " +
            "id="+ i + ">" + persons[i].last_name + " " + persons[i].first_name + "</button>";

    }
}

function asc() {
    detail=[]
    for(var i = 0; i < persons.length; i++){
        detail[i]=persons[i].last_name;
    }
    detail.sort();
}